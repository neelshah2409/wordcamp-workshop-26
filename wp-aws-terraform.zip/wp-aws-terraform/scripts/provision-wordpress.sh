#!/bin/bash
# =============================================================================
# provision-wordpress.sh
# Run this on the server AFTER bootstrap.sh has completed (check the log).
#
# Usage:
#   ssh -i ~/.ssh/your-key.pem ubuntu@<YOUR_IP>
#   sudo bash /path/to/provision-wordpress.sh
#
# Or copy it to the server first:
#   scp -i ~/.ssh/your-key.pem scripts/provision-wordpress.sh ubuntu@<YOUR_IP>:~
#   ssh -i ~/.ssh/your-key.pem ubuntu@<YOUR_IP> "sudo bash ~/provision-wordpress.sh"
#
# What this script does:
#   1. Downloads WordPress core
#   2. Creates wp-config.php  (database connection, security keys)
#   3. Installs WordPress     (sets up the DB tables, creates admin user)
#   4. Installs plugins       (Yoast SEO, WooCommerce, Wordfence)
#   5. Installs a theme       (Astra — lightweight, WooCommerce-compatible)
#   6. Applies hardening tweaks
# =============================================================================

set -euo pipefail
exec > >(tee /var/log/provision-wordpress.log | logger -t provision-wp) 2>&1

echo "===== WordPress provisioning started at $(date) ====="

# ── Load credentials written by bootstrap.sh ──────────────────────────────────
if [[ ! -f /root/.wp-env ]]; then
  echo "ERROR: /root/.wp-env not found. Did bootstrap.sh complete successfully?"
  echo "Check: tail -50 /var/log/bootstrap.log"
  exit 1
fi
# shellcheck source=/dev/null
source /root/.wp-env

# ── Configuration — edit these for your workshop site ─────────────────────────
WP_DIR="/var/www/wordpress"
WP_URL="http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)"
WP_TITLE="My Workshop Site"
WP_ADMIN_USER="admin"
WP_ADMIN_PASSWORD="W0rdCamp2025!"   # change this immediately after the workshop
WP_ADMIN_EMAIL="admin@example.com"
WP_LOCALE="en_US"

# =============================================================================
# STEP 1 — Download WordPress core
# =============================================================================
echo "----- Step 1: Download WordPress -----"

# Run WP-CLI as www-data (the web server user) — file permissions will be correct
sudo -u www-data wp core download \
  --path="$WP_DIR" \
  --locale="$WP_LOCALE" \
  --allow-root

echo "WordPress core downloaded to $WP_DIR"

# =============================================================================
# STEP 2 — Create wp-config.php
# =============================================================================
echo "----- Step 2: Create wp-config.php -----"

sudo -u www-data wp config create \
  --path="$WP_DIR" \
  --dbname="$WP_DB_NAME" \
  --dbuser="$WP_DB_USER" \
  --dbpass="$WP_DB_PASSWORD" \
  --dbhost="$WP_DB_HOST" \
  --dbprefix="wp_" \
  --allow-root

# Add extra constants to wp-config.php for security and performance
sudo -u www-data wp config set WP_DEBUG         false  --raw --path="$WP_DIR" --allow-root
sudo -u www-data wp config set WP_DEBUG_LOG     false  --raw --path="$WP_DIR" --allow-root
sudo -u www-data wp config set DISALLOW_FILE_EDIT true --raw --path="$WP_DIR" --allow-root
# ↑ DISALLOW_FILE_EDIT removes the theme/plugin editor from WP admin —
#   a key hardening step (attackers can't edit PHP through the dashboard).

echo "wp-config.php created."

# =============================================================================
# STEP 3 — Install WordPress (creates DB tables, admin user)
# =============================================================================
echo "----- Step 3: Run WordPress install -----"

sudo -u www-data wp core install \
  --path="$WP_DIR" \
  --url="$WP_URL" \
  --title="$WP_TITLE" \
  --admin_user="$WP_ADMIN_USER" \
  --admin_password="$WP_ADMIN_PASSWORD" \
  --admin_email="$WP_ADMIN_EMAIL" \
  --skip-email \
  --allow-root

echo "WordPress installed. Admin: $WP_ADMIN_USER / $WP_ADMIN_PASSWORD"

# =============================================================================
# STEP 4 — Install & activate plugins
# =============================================================================
echo "----- Step 4: Plugins -----"

# Format: wp plugin install <slug-or-zip-url> --activate
# Slugs come from the wordpress.org plugin directory URL.

PLUGINS=(
  "wordpress-seo"        # Yoast SEO — most popular SEO plugin
  "woocommerce"          # WooCommerce — e-commerce layer
  "wordfence"            # Wordfence Security — firewall + malware scan
  "w3-total-cache"       # W3 Total Cache — caching layer
  "updraftplus"          # UpdraftPlus — backup plugin
)

for plugin in "${PLUGINS[@]}"; do
  echo "Installing plugin: $plugin"
  sudo -u www-data wp plugin install "$plugin" --activate \
    --path="$WP_DIR" --allow-root
done

echo "All plugins installed and activated."

# =============================================================================
# STEP 5 — Install & activate theme
# =============================================================================
echo "----- Step 5: Theme -----"

# Astra: fast, lightweight, works well with WooCommerce and Gutenberg.
sudo -u www-data wp theme install astra --activate \
  --path="$WP_DIR" --allow-root

echo "Theme 'astra' activated."

# =============================================================================
# STEP 6 — Content & settings
# =============================================================================
echo "----- Step 6: Settings & sample content -----"

# Set permalink structure to /%postname%/ (human-readable URLs)
sudo -u www-data wp rewrite structure '/%postname%/' \
  --path="$WP_DIR" --allow-root
sudo -u www-data wp rewrite flush \
  --path="$WP_DIR" --allow-root

# Set timezone
sudo -u www-data wp option update timezone_string "Asia/Singapore" \
  --path="$WP_DIR" --allow-root

# Remove the default "Hello world!" post and "Sample Page"
sudo -u www-data wp post delete 1 2 --force \
  --path="$WP_DIR" --allow-root 2>/dev/null || true

# Create a "Welcome" page
sudo -u www-data wp post create \
  --post_type=page \
  --post_title="Welcome to $WP_TITLE" \
  --post_content="This site was deployed automatically using Terraform and WP-CLI." \
  --post_status=publish \
  --path="$WP_DIR" --allow-root

echo "Content and settings configured."

# =============================================================================
# STEP 7 — File permissions hardening
# =============================================================================
echo "----- Step 7: File permissions -----"

# WordPress recommended permissions:
#   Directories: 755  (owner read/write/execute, others read/execute)
#   Files:       644  (owner read/write, others read-only)
#   wp-config:   600  (owner only — contains DB credentials)
find "$WP_DIR" -type d -exec chmod 755 {} \;
find "$WP_DIR" -type f -exec chmod 644 {} \;
chmod 600 "$WP_DIR/wp-config.php"

# Everything should be owned by www-data (the Nginx/PHP process user)
chown -R www-data:www-data "$WP_DIR"

echo "File permissions set."

# =============================================================================
# Done!
# =============================================================================
echo ""
echo "===== WordPress provisioning completed at $(date) ====="
echo ""
echo "  Site URL:  $WP_URL"
echo "  Admin URL: $WP_URL/wp-admin"
echo "  Username:  $WP_ADMIN_USER"
echo "  Password:  $WP_ADMIN_PASSWORD"
echo ""
echo "⚠️  Change the admin password immediately: $WP_URL/wp-admin/profile.php"

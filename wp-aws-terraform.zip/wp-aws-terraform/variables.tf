# =============================================================================
# variables.tf — All input variables for the root module
# Set values in terraform.tfvars (never commit that file to git).
# =============================================================================

# ── Project identity ──────────────────────────────────────────────────────────

variable "project" {
  description = "Short project slug. Used in resource Name tags."
  type        = string
  default     = "wp-workshop"
}

variable "environment" {
  description = "Deployment environment: dev | staging | prod"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

# ── AWS region ───────────────────────────────────────────────────────────────

variable "aws_region" {
  description = "AWS region to deploy into. ap-southeast-1 = Singapore, closest for WordCamp Asia."
  type        = string
  default     = "ap-southeast-1"
}

# ── Networking ───────────────────────────────────────────────────────────────

variable "vpc_cidr" {
  description = "CIDR block for the VPC. /16 gives us 65 536 addresses — plenty."
  type        = string
  default     = "10.0.0.0/16"
}

# ── Security ─────────────────────────────────────────────────────────────────

variable "your_ip" {
  description = <<EOT
Your public IP in CIDR notation, e.g. "203.0.113.42/32".
SSH port 22 will only be open to this address.
Find yours at: https://checkip.amazonaws.com
EOT
  type        = string
  # No default — you MUST supply this. SSH open to 0.0.0.0/0 is a bad practice.
}

# ── EC2 instance ─────────────────────────────────────────────────────────────

variable "instance_type" {
  description = "EC2 instance type. t3.micro is free-tier eligible."
  type        = string
  default     = "t3.micro"
}

variable "ami_id" {
  description = <<EOT
Ubuntu 22.04 LTS AMI ID. AMI IDs are region-specific — check AWS console or use:
  aws ec2 describe-images \
    --owners 099720109477 \
    --filters "Name=name,Values=ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*" \
    --query "sort_by(Images,&CreationDate)[-1].ImageId" \
    --region ap-southeast-1
EOT
  type        = string
  # Default is Ubuntu 22.04 LTS in ap-southeast-1 as of early 2025.
  # Always verify before a live workshop — AMIs are updated regularly.
  default     = "ami-0df7a207adb9748c7"
}

variable "key_name" {
  description = <<EOT
Name of an existing EC2 Key Pair for SSH access.
Create one in the AWS console → EC2 → Key Pairs, download the .pem file.
  chmod 400 ~/Downloads/your-key.pem
EOT
  type        = string
}

variable "root_volume_size" {
  description = "Root EBS volume size in GB. 20 GB is comfortable for a WordPress site."
  type        = number
  default     = 20
}

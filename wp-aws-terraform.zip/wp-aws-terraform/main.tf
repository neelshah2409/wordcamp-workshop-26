# =============================================================================
# main.tf — Root configuration
# Wires together networking, security, and EC2 modules.
# Run from this directory: terraform init → plan → apply
# =============================================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"   # pin to major version to avoid breaking changes
    }
  }

  # ── Optional: store state remotely so the team shares the same source of truth
  # Uncomment and fill in your bucket name + DynamoDB table after creating them.
  #
  # backend "s3" {
  #   bucket         = "your-tfstate-bucket"
  #   key            = "wordpress/terraform.tfstate"
  #   region         = "ap-southeast-1"
  #   dynamodb_table = "terraform-state-lock"
  #   encrypt        = true
  # }
}

# ── AWS Provider
# Reads AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY from environment.
# Never hard-code credentials here.
provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "wordpress-workshop"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

# ── Networking module
# Creates VPC, public subnet, internet gateway, and route table.
module "networking" {
  source = "./modules/networking"

  project     = var.project
  environment = var.environment
  vpc_cidr    = var.vpc_cidr
  aws_region  = var.aws_region
}

# ── Security module
# Creates security group with rules for SSH, HTTP, HTTPS.
module "security" {
  source = "./modules/security"

  project    = var.project
  vpc_id     = module.networking.vpc_id
  your_ip    = var.your_ip   # restricts SSH to your IP only
}

# ── EC2 module
# Launches the Ubuntu instance and injects the bootstrap script via user_data.
module "ec2" {
  source = "./modules/ec2"

  project           = var.project
  environment       = var.environment
  instance_type     = var.instance_type
  ami_id            = var.ami_id
  key_name          = var.key_name
  subnet_id         = module.networking.public_subnet_id
  security_group_id = module.security.web_sg_id
  root_volume_size  = var.root_volume_size
}

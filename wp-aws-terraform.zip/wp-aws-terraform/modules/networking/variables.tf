# modules/networking/variables.tf

variable "project"     { type = string }
variable "environment" { type = string }
variable "vpc_cidr"    { type = string }
variable "aws_region"  { type = string }

# =============================================================================
# modules/networking/main.tf
# Creates:
#   • VPC
#   • Public subnet  (instances here get a public IP)
#   • Internet Gateway  (allows outbound internet — needed to install packages)
#   • Route table + association  (routes 0.0.0.0/0 through the IGW)
# =============================================================================

# ── VPC ───────────────────────────────────────────────────────────────────────
# The VPC is your private network boundary inside AWS.
# All other resources live inside it.
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true   # required for Route 53 and instance hostname resolution
  enable_dns_hostnames = true   # gives instances a public DNS name alongside their IP

  tags = {
    Name = "${var.project}-vpc"
  }
}

# ── Public subnet ─────────────────────────────────────────────────────────────
# We use a single AZ for the workshop to keep things simple.
# In production you'd add a second subnet in a second AZ for HA.
resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = cidrsubnet(var.vpc_cidr, 8, 1)  # e.g. 10.0.1.0/24 from 10.0.0.0/16
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = true   # instances launched here automatically get a public IP

  tags = {
    Name = "${var.project}-public-subnet"
  }
}

# ── Internet Gateway ──────────────────────────────────────────────────────────
# Without this, the VPC is completely isolated — no internet, no package installs.
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${var.project}-igw"
  }
}

# ── Route table ───────────────────────────────────────────────────────────────
# Routes all non-local traffic (0.0.0.0/0) through the Internet Gateway.
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name = "${var.project}-public-rt"
  }
}

# ── Route table association ───────────────────────────────────────────────────
# Links the route table to the public subnet.
# Without this, the subnet doesn't know to use the IGW.
resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

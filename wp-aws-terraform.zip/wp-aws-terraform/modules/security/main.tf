# =============================================================================
# modules/security/main.tf
# Creates a Security Group — AWS's stateful firewall for EC2 instances.
#
# Rules:
#   Inbound  22   — SSH, restricted to your IP only
#   Inbound  80   — HTTP, open to world (WordPress needs this)
#   Inbound  443  — HTTPS, open to world (for after you add TLS)
#   Outbound all  — allow everything out (needed for apt, yum, WP downloads)
# =============================================================================

resource "aws_security_group" "web" {
  name        = "${var.project}-web-sg"
  description = "Allow SSH from my IP, HTTP/HTTPS from anywhere"
  vpc_id      = var.vpc_id

  # ── Inbound: SSH ─────────────────────────────────────────────────────────
  # Locked to your_ip only. Opening this to 0.0.0.0/0 would expose you
  # to brute-force attacks within minutes on a fresh public IP.
  ingress {
    description = "SSH from my IP"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.your_ip]
  }

  # ── Inbound: HTTP ─────────────────────────────────────────────────────────
  # WordPress runs on port 80 by default. Certbot (Let's Encrypt) also needs
  # port 80 open for the HTTP-01 challenge when issuing TLS certificates.
  ingress {
    description = "HTTP from anywhere"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # ── Inbound: HTTPS ────────────────────────────────────────────────────────
  # Open now so you don't have to touch the security group after adding TLS.
  ingress {
    description = "HTTPS from anywhere"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # ── Outbound: all traffic ─────────────────────────────────────────────────
  # Allows the instance to reach the internet for:
  #   apt update / apt install  (Ubuntu package manager)
  #   WP-CLI downloads
  #   WordPress plugin/theme updates
  egress {
    description = "Allow all outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"          # -1 = all protocols
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project}-web-sg"
  }
}

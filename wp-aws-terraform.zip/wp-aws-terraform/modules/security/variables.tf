# modules/security/variables.tf

variable "project"  { type = string }
variable "vpc_id"   { type = string }
variable "your_ip"  { type = string }

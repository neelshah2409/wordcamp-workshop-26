# =============================================================================
# modules/ec2/main.tf
# Creates:
#   • EC2 instance  (Ubuntu 22.04, your chosen type)
#   • Root EBS volume  (20 GB gp3 — faster & cheaper than gp2)
#   • Elastic IP  (static public IP that survives stop/start)
#   • user_data script  (runs once on first boot, installs LEMP stack)
# =============================================================================

# ── EC2 instance ──────────────────────────────────────────────────────────────
resource "aws_instance" "wordpress" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name

  # user_data runs as root the very first time the instance boots.
  # It installs Nginx, MySQL, PHP — the full LEMP stack.
  # templatefile() reads the script and substitutes ${} variables.
  user_data = templatefile("${path.module}/scripts/bootstrap.sh", {
    db_name     = "wordpress"
    db_user     = "wp_user"
    db_password = "Ch4ngeM3_${var.project}"   # workshop default — override in prod!
    php_version = "8.2"
  })

  # ── Root volume ─────────────────────────────────────────────────────────
  root_block_device {
    volume_type           = "gp3"      # gp3 is the current gen — 20% cheaper than gp2
    volume_size           = var.root_volume_size
    delete_on_termination = true       # cleans up EBS when you terraform destroy
    encrypted             = true       # encrypt at rest — good habit even for workshops
  }

  # Wait for the instance to pass both AWS status checks before Terraform
  # marks it as complete. Without this, outputs (IP) appear before the
  # instance is actually reachable.
  lifecycle {
    create_before_destroy = true
  }

  tags = {
    Name = "${var.project}-${var.environment}-server"
  }
}

# ── Elastic IP ────────────────────────────────────────────────────────────────
# An Elastic IP is a static public address.
# Without it, stopping + starting the instance gives you a new IP — annoying
# during a workshop when everyone has the IP written down.
resource "aws_eip" "wordpress" {
  instance = aws_instance.wordpress.id
  domain   = "vpc"

  # The EIP depends on the IGW existing — AWS requires this.
  depends_on = [aws_instance.wordpress]

  tags = {
    Name = "${var.project}-eip"
  }
}

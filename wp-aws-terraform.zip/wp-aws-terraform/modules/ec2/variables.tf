# modules/ec2/variables.tf

variable "project"           { type = string }
variable "environment"       { type = string }
variable "ami_id"            { type = string }
variable "instance_type"     { type = string }
variable "key_name"          { type = string }
variable "subnet_id"         { type = string }
variable "security_group_id" { type = string }
variable "root_volume_size"  { type = number }

#!/bin/bash
# =============================================================================
# bootstrap.sh — Runs as root on first boot via EC2 user_data
#
# What this script does, in order:
#   1. Updates the OS and installs all packages
#   2. Configures MySQL (creates DB + user for WordPress)
#   3. Configures PHP 8.2
#   4. Configures Nginx with a WordPress-ready server block
#   5. Installs WP-CLI (the WordPress command-line tool)
#   6. Creates a log file you can tail to watch progress
#
# To watch it run live after SSH-ing in:
#   tail -f /var/log/bootstrap.log
#
# Template variables (substituted by Terraform's templatefile()):
#   ${db_name}     — WordPress database name
#   ${db_user}     — MySQL user for WordPress
#   ${db_password} — MySQL password (change this before production use!)
#   ${php_version} — PHP version to install (8.2)
# =============================================================================

set -euo pipefail   # exit on error, undefined vars, pipe failures
exec > >(tee /var/log/bootstrap.log | logger -t bootstrap) 2>&1
# ↑ All output goes to /var/log/bootstrap.log AND the system journal.

echo "===== Bootstrap started at $(date) ====="

# =============================================================================
# STEP 1 — System update & package installation
# =============================================================================
echo "----- Step 1: System update -----"

export DEBIAN_FRONTEND=noninteractive   # prevent apt from asking interactive questions

apt-get update -y
apt-get upgrade -y

# Add the Ondrej PHP PPA — Ubuntu's default repos often have older PHP versions
apt-get install -y software-properties-common
add-apt-repository -y ppa:ondrej/php
apt-get update -y

# Install everything in one shot — fewer round trips, faster boot
apt-get install -y \
  nginx \
  mysql-server \
  php${php_version}-fpm \
  php${php_version}-mysql \
  php${php_version}-xml \
  php${php_version}-mbstring \
  php${php_version}-curl \
  php${php_version}-zip \
  php${php_version}-gd \
  php${php_version}-intl \
  php${php_version}-bcmath \
  php${php_version}-imagick \
  php${php_version}-redis \
  curl \
  unzip \
  git

echo "Packages installed successfully."

# =============================================================================
# STEP 2 — MySQL configuration
# =============================================================================
echo "----- Step 2: MySQL setup -----"

# Start MySQL (may already be running, || true prevents exit on "already active")
systemctl start mysql || true
systemctl enable mysql

# Run all MySQL setup as a heredoc — cleaner than separate mysql commands.
# Note: on Ubuntu 22.04, the root user uses auth_socket by default (no password).
mysql --user=root <<SQL
  -- Create the WordPress database
  CREATE DATABASE IF NOT EXISTS \`${db_name}\`
    CHARACTER SET utf8mb4        -- full Unicode + emoji support
    COLLATE utf8mb4_unicode_ci;

  -- Create the application user
  -- Only allow connections from localhost (WordPress is on the same server)
  CREATE USER IF NOT EXISTS '${db_user}'@'localhost'
    IDENTIFIED BY '${db_password}';

  -- Grant only the permissions WordPress actually needs
  GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER
    ON \`${db_name}\`.* TO '${db_user}'@'localhost';

  -- Remove the anonymous test users that ship with MySQL
  DELETE FROM mysql.user WHERE User='';
  DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost','127.0.0.1','::1');

  -- Disable remote root login
  DELETE FROM mysql.db WHERE Db='test' OR Db='test_%';

  FLUSH PRIVILEGES;
SQL

echo "MySQL configured: database='${db_name}', user='${db_user}'"

# =============================================================================
# STEP 3 — PHP-FPM configuration
# =============================================================================
echo "----- Step 3: PHP-FPM -----"

# Tune PHP settings for WordPress
PHP_INI="/etc/php/${php_version}/fpm/php.ini"

# upload_max_filesize — lets editors upload large images/videos
sed -i 's/^upload_max_filesize.*/upload_max_filesize = 64M/'   "$PHP_INI"
sed -i 's/^post_max_size.*/post_max_size = 64M/'               "$PHP_INI"
# memory_limit — WordPress plugins can be memory-hungry
sed -i 's/^memory_limit.*/memory_limit = 256M/'                "$PHP_INI"
# max_execution_time — prevents plugin installs from timing out
sed -i 's/^max_execution_time.*/max_execution_time = 300/'     "$PHP_INI"

# Use the socket path that Nginx will reference
PHP_FPM_CONF="/etc/php/${php_version}/fpm/pool.d/www.conf"
sed -i "s|^listen = .*|listen = /run/php/php${php_version}-fpm.sock|" "$PHP_FPM_CONF"

systemctl restart php${php_version}-fpm
systemctl enable  php${php_version}-fpm

echo "PHP ${php_version}-FPM configured and running."

# =============================================================================
# STEP 4 — Nginx configuration
# =============================================================================
echo "----- Step 4: Nginx -----"

# Remove the default placeholder site
rm -f /etc/nginx/sites-enabled/default

# Write a WordPress-optimised server block
cat > /etc/nginx/sites-available/wordpress <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;

    root /var/www/wordpress;
    index index.php index.html;

    server_name _;   # catch-all — works with IP address before you add a domain

    # ── WordPress permalink support ──────────────────────────────────────
    # try_files checks if the URL is a real file/dir; if not, passes to index.php
    # This is what makes /my-blog-post/ work instead of ?p=123
    location / {
        try_files $uri $uri/ /index.php?$args;
    }

    # ── PHP processing ───────────────────────────────────────────────────
    location ~ \.php$ {
        include        snippets/fastcgi-php.conf;
        fastcgi_pass   unix:/run/php/phpPHP_VERSION-fpm.sock;
        fastcgi_param  SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include        fastcgi_params;
    }

    # ── Security: hide sensitive files ───────────────────────────────────
    location ~ /\. {
        deny all;   # blocks .htaccess, .env, .git etc.
    }

    # ── Static asset caching ─────────────────────────────────────────────
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|woff2)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # ── Block xmlrpc.php (common brute-force target) ──────────────────────
    location = /xmlrpc.php {
        deny all;
    }

    # ── Upload size limit — must match PHP settings ───────────────────────
    client_max_body_size 64M;
}
NGINX

# Substitute the PHP version placeholder in the Nginx config
sed -i "s/PHP_VERSION/${php_version}/g" /etc/nginx/sites-available/wordpress

# Enable the site
ln -sf /etc/nginx/sites-available/wordpress /etc/nginx/sites-enabled/wordpress

# Create the web root directory
mkdir -p /var/www/wordpress
chown -R www-data:www-data /var/www/wordpress

# Test config before reloading — prevents a broken config from killing Nginx
nginx -t
systemctl restart nginx
systemctl enable  nginx

echo "Nginx configured for WordPress."

# =============================================================================
# STEP 5 — Install WP-CLI
# =============================================================================
echo "----- Step 5: WP-CLI -----"

# WP-CLI is the WordPress command-line interface.
# It lets us install, configure, and manage WordPress without a browser.
curl -sS -o /usr/local/bin/wp https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar

chmod +x /usr/local/bin/wp

# Verify installation
wp --info --allow-root

echo "WP-CLI installed: $(wp --version --allow-root)"

# =============================================================================
# STEP 6 — Write WordPress config file for WP-CLI to use later
# =============================================================================
echo "----- Step 6: Write DB credentials for WP-CLI -----"

# Store credentials in a file the next script (provision-wordpress.sh) can read.
# chmod 600 means only root can read this file.
cat > /root/.wp-env <<EOF
WP_DB_NAME=${db_name}
WP_DB_USER=${db_user}
WP_DB_PASSWORD=${db_password}
WP_DB_HOST=localhost
EOF
chmod 600 /root/.wp-env

echo "===== Bootstrap completed at $(date) ====="
echo "LEMP stack is ready. Next step: run scripts/provision-wordpress.sh"

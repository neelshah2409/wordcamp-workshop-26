# modules/ec2/outputs.tf

output "instance_id" {
  description = "EC2 instance ID"
  value       = aws_instance.wordpress.id
}

output "public_ip" {
  description = "Elastic (static) public IP"
  value       = aws_eip.wordpress.public_ip
}

output "private_ip" {
  description = "Private IP — useful if you add an RDS instance in the same VPC"
  value       = aws_instance.wordpress.private_ip
}

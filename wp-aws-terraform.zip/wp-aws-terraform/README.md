# WordPress on AWS EC2 — Terraform + LEMP Stack

Workshop repo for **"From On-Demand to Cloud: Automate WordPress Installations Like a Pro"**  
WordCamp Asia · 90-minute hands-on session

---

## Prerequisites

| Tool | Version | Install |
|---|---|---|
| Terraform | ≥ 1.6 | https://developer.hashicorp.com/terraform/install |
| AWS CLI | ≥ 2 | https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html |
| An AWS account | Free tier works | https://aws.amazon.com/free |

---

## Step-by-step setup

### 1 — Configure AWS credentials

```bash
# Option A: environment variables (recommended for workshops)
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_DEFAULT_REGION="ap-southeast-1"

# Option B: AWS CLI config
aws configure
# prompts for key, secret, region, output format
```

### 2 — Create an EC2 Key Pair

```bash
# Create the key pair and save the private key
aws ec2 create-key-pair \
  --key-name wp-workshop-key \
  --query 'KeyMaterial' \
  --output text > ~/.ssh/wp-workshop-key.pem

# Lock down permissions — SSH refuses keys that are too open
chmod 400 ~/.ssh/wp-workshop-key.pem
```

### 3 — Find your public IP

```bash
# Your IP must be in CIDR notation, e.g. 203.0.113.42/32
curl https://checkip.amazonaws.com
# → 203.0.113.42
# Append /32: 203.0.113.42/32
```

### 4 — Create your tfvars file

```bash
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars — fill in your_ip and key_name
```

### 5 — Initialise Terraform

```bash
terraform init
# Downloads the AWS provider plugin (~50 MB)
# Output: "Terraform has been successfully initialized!"
```

### 6 — Preview the plan

```bash
terraform plan
# Shows exactly what will be created — no changes made yet.
# You should see: 7 resources to add, 0 to change, 0 to destroy.
```

### 7 — Apply (provision the infrastructure)

```bash
terraform apply
# Type 'yes' when prompted.
# Takes ~60 seconds. Watch for:
#   aws_vpc.main
#   aws_subnet.public
#   aws_internet_gateway.main
#   aws_route_table.public
#   aws_security_group.web
#   aws_instance.wordpress
#   aws_eip.wordpress

# When complete, Terraform prints:
#   instance_public_ip = "x.x.x.x"
#   ssh_command        = "ssh -i ~/.ssh/wp-workshop-key.pem ubuntu@x.x.x.x"
#   site_url           = "http://x.x.x.x"
```

### 8 — Watch the bootstrap run

```bash
# SSH in (wait ~30 seconds for the instance to be reachable)
ssh -i ~/.ssh/wp-workshop-key.pem ubuntu@$(terraform output -raw instance_public_ip)

# Watch the LEMP stack install in real time
sudo tail -f /var/log/bootstrap.log

# When you see "Bootstrap completed" — the server is ready.
```

### 9 — Deploy WordPress

```bash
# Copy the WordPress provisioning script to the server
scp -i ~/.ssh/wp-workshop-key.pem \
  scripts/provision-wordpress.sh \
  ubuntu@$(terraform output -raw instance_public_ip):~

# SSH in and run it
ssh -i ~/.ssh/wp-workshop-key.pem ubuntu@$(terraform output -raw instance_public_ip)
sudo bash ~/provision-wordpress.sh

# Watch for:
#   Site URL:  http://x.x.x.x
#   Admin URL: http://x.x.x.x/wp-admin
```

### 10 — Open your site

```bash
# Print the URL
terraform output site_url

# Open in browser
open $(terraform output -raw site_url)       # macOS
xdg-open $(terraform output -raw site_url)   # Linux
```

---

## Useful commands during the workshop

```bash
# Re-read outputs at any time
terraform output

# SSH shortcut
ssh -i ~/.ssh/wp-workshop-key.pem ubuntu@$(terraform output -raw instance_public_ip)

# Check all services are running (run on server)
sudo systemctl status nginx php8.2-fpm mysql

# WP-CLI: list installed plugins
sudo -u www-data wp plugin list --path=/var/www/wordpress

# WP-CLI: install an extra plugin
sudo -u www-data wp plugin install contact-form-7 --activate --path=/var/www/wordpress

# WP-CLI: create a new user
sudo -u www-data wp user create editor editor@example.com \
  --role=editor --path=/var/www/wordpress

# Check bootstrap log
sudo tail -100 /var/log/bootstrap.log

# Check WordPress provision log
sudo tail -100 /var/log/provision-wordpress.log
```

---

## Tear down (important — stops AWS charges)

```bash
# Destroys EVERYTHING created by this repo — VPC, EC2, EIP, etc.
# Your tfvars and state file stay locally.
terraform destroy
# Type 'yes' when prompted.
```

---

## Repo structure

```
wp-aws-terraform/
├── main.tf                        # Root — wires modules together
├── variables.tf                   # All input variable definitions
├── outputs.tf                     # Values printed after apply
├── terraform.tfvars.example       # Template — copy to terraform.tfvars
├── .gitignore
├── scripts/
│   └── provision-wordpress.sh     # Run on server to install WP
└── modules/
    ├── networking/
    │   ├── main.tf                # VPC, subnet, IGW, route table
    │   ├── variables.tf
    │   └── outputs.tf
    ├── security/
    │   ├── main.tf                # Security group rules
    │   ├── variables.tf
    │   └── outputs.tf
    └── ec2/
        ├── main.tf                # EC2 instance + Elastic IP
        ├── variables.tf
        ├── outputs.tf
        └── scripts/
            └── bootstrap.sh       # Runs on first boot via user_data
```

---

## Common errors & fixes

| Error | Cause | Fix |
|---|---|---|
| `InvalidKeyPair.NotFound` | Key pair name mismatch | Check `key_name` in tfvars matches the AWS console exactly |
| SSH: `Permission denied (publickey)` | Wrong key file or permissions | `chmod 400 ~/.ssh/your-key.pem` |
| SSH: `Connection refused` | Instance still booting | Wait 30–60 s and retry |
| Nginx 502 Bad Gateway | PHP-FPM not running | `sudo systemctl restart php8.2-fpm` |
| `Error: No valid credential sources found` | AWS credentials not set | Run `aws configure` or export env vars |
| `UnauthorizedOperation` | IAM user lacks EC2 permissions | Attach `AmazonEC2FullAccess` policy in IAM console |

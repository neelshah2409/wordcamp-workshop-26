# =============================================================================
# outputs.tf — Values printed after terraform apply
# Use these to SSH in and configure WordPress.
# =============================================================================

output "instance_public_ip" {
  description = "Public IP of the EC2 instance. Use this to SSH and to visit the site."
  value       = module.ec2.public_ip
}

output "instance_id" {
  description = "EC2 instance ID — useful for aws cli commands."
  value       = module.ec2.instance_id
}

output "ssh_command" {
  description = "Ready-to-run SSH command. Replace the key path if yours differs."
  value       = "ssh -i ~/.ssh/${var.key_name}.pem ubuntu@${module.ec2.public_ip}"
}

output "site_url" {
  description = "WordPress site URL (HTTP until you add a domain + TLS)."
  value       = "http://${module.ec2.public_ip}"
}

output "wp_admin_url" {
  description = "WordPress admin login page."
  value       = "http://${module.ec2.public_ip}/wp-admin"
}

output "vpc_id" {
  description = "VPC ID — useful for adding RDS or ElastiCache later."
  value       = module.networking.vpc_id
}
